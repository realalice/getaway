"use client"

import { useState } from "react"
import { ComposableMap, Geographies, Geography, ZoomableGroup } from "react-simple-maps"
import { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider } from "@/components/ui/tooltip"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"

// URL to a TopoJSON resource for world countries
const geoUrl = "https://raw.githubusercontent.com/deldersveld/topojson/master/world-countries.json"

// Sample country data - in a real app, you would fetch this from an API
const countryData: Record<string, { capital: string; population: string; area: string }> = {
  USA: {
    capital: "Washington, D.C.",
    population: "331 million",
    area: "9.8 million km²",
  },
  CAN: {
    capital: "Ottawa",
    population: "38 million",
    area: "9.98 million km²",
  },
  GBR: {
    capital: "London",
    population: "67 million",
    area: "242,495 km²",
  },
  FRA: {
    capital: "Paris",
    population: "67 million",
    area: "551,695 km²",
  },
  DEU: {
    capital: "Berlin",
    population: "83 million",
    area: "357,022 km²",
  },
  JPN: {
    capital: "Tokyo",
    population: "126 million",
    area: "377,975 km²",
  },
  AUS: {
    capital: "Canberra",
    population: "25 million",
    area: "7.7 million km²",
  },
  BRA: {
    capital: "Brasília",
    population: "212 million",
    area: "8.5 million km²",
  },
  IND: {
    capital: "New Delhi",
    population: "1.38 billion",
    area: "3.3 million km²",
  },
  CHN: {
    capital: "Beijing",
    population: "1.4 billion",
    area: "9.6 million km²",
  },
  ZAF: {
    capital: "Pretoria (administrative), Cape Town (legislative), Bloemfontein (judicial)",
    population: "59 million",
    area: "1.2 million km²",
  },
  RUS: {
    capital: "Moscow",
    population: "144 million",
    area: "17.1 million km²",
  },
}

export default function WorldMap() {
  const [tooltipContent, setTooltipContent] = useState("")
  const [position, setPosition] = useState({ coordinates: [0, 0], zoom: 1 })
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null)
  const [countryInfo, setCountryInfo] = useState<any>(null)

  function handleZoomIn() {
    if (position.zoom >= 4) return
    setPosition((pos) => ({ ...pos, zoom: pos.zoom * 1.5 }))
  }

  function handleZoomOut() {
    if (position.zoom <= 1) return
    setPosition((pos) => ({ ...pos, zoom: pos.zoom / 1.5 }))
  }

  function handleMoveEnd(position: any) {
    setPosition(position)
  }

  function handleCountryClick(geo: any) {
    const { NAME, ISO_A3 } = geo.properties
    setSelectedCountry(NAME)
    setCountryInfo(countryData[ISO_A3] || null)
  }

  return (
    <div className="relative h-full">
      <div className="absolute top-2 right-2 z-10 flex gap-2">
        <button className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100" onClick={handleZoomIn}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-plus"
          >
            <path d="M5 12h14" />
            <path d="M12 5v14" />
          </svg>
        </button>
        <button className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100" onClick={handleZoomOut}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-minus"
          >
            <path d="M5 12h14" />
          </svg>
        </button>
      </div>

      <TooltipProvider>
        <ComposableMap projection="geoMercator" className="h-full w-full">
          <ZoomableGroup
            zoom={position.zoom}
            center={position.coordinates as [number, number]}
            onMoveEnd={handleMoveEnd}
          >
            <Geographies geography={geoUrl}>
              {({ geographies }) =>
                geographies.map((geo) => (
                  <Tooltip key={geo.rsmKey}>
                    <TooltipTrigger asChild>
                      <Geography
                        geography={geo}
                        onMouseEnter={() => {
                          setTooltipContent(geo.properties.NAME)
                        }}
                        onMouseLeave={() => {
                          setTooltipContent("")
                        }}
                        onClick={() => handleCountryClick(geo)}
                        style={{
                          default: {
                            fill: "#D6D6DA",
                            outline: "none",
                            stroke: "#FFFFFF",
                            strokeWidth: 0.5,
                          },
                          hover: {
                            fill: "#F53",
                            outline: "none",
                            stroke: "#FFFFFF",
                            strokeWidth: 0.5,
                            cursor: "pointer",
                          },
                          pressed: {
                            fill: "#E42",
                            outline: "none",
                          },
                        }}
                      />
                    </TooltipTrigger>
                    <TooltipContent>{geo.properties.NAME}</TooltipContent>
                  </Tooltip>
                ))
              }
            </Geographies>
          </ZoomableGroup>
        </ComposableMap>
      </TooltipProvider>

      <Dialog open={!!selectedCountry} onOpenChange={(open) => !open && setSelectedCountry(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedCountry}</DialogTitle>
            <DialogDescription>
              {countryInfo ? (
                <div className="mt-4 space-y-2">
                  <p>
                    <strong>Capital:</strong> {countryInfo.capital}
                  </p>
                  <p>
                    <strong>Population:</strong> {countryInfo.population}
                  </p>
                  <p>
                    <strong>Area:</strong> {countryInfo.area}
                  </p>
                </div>
              ) : (
                <p className="mt-4">No detailed information available for this country.</p>
              )}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  )
}
